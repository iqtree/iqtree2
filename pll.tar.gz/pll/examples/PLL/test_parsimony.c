#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "../../src/pll.h"

int main(int argc, char * argv[]) {
	pllAlignmentData * alignmentData;
	pllInstance * tr;
	pllNewickTree * newick1;
	partitionList * partitions;
	pllQueue * partitionInfo;
	int i, j;
	pllInstanceAttr attr;
	pllRearrangeList * rearrangeList;

	if (argc != 3) {
		fprintf(stderr,
				"usage: %s [phylip-file] [partition-file]\n",
				argv[0]);
		return (EXIT_FAILURE);
	}

	/* Set the PLL instance attributes */
	attr.rateHetModel = PLL_GAMMA;
	attr.fastScaling = PLL_FALSE;
	attr.saveMemory = PLL_FALSE;
	attr.useRecom = PLL_FALSE;
	attr.randomNumberSeed = 0xDEADBEEF;
	attr.numberOfThreads = 8; /* This only affects the pthreads version */

	/* Create a PLL tree */
	tr = pllCreateInstance(&attr);

	/* Parse a PHYLIP file */
	alignmentData = pllParseAlignmentFile(PLL_FORMAT_PHYLIP, argv[1]);

	if (!alignmentData) {
		fprintf(stderr, "Error while parsing %s\n", argv[1]);
		return (EXIT_FAILURE);
	}

	/* Parse the partitions file into a partition queue structure */
	partitionInfo = pllPartitionParse(argv[2]);

	/* Validate the partitions */
	if (!pllPartitionsValidate(partitionInfo, alignmentData)) {
		fprintf(stderr, "Error: Partitions do not cover all sites\n");
		return (EXIT_FAILURE);
	}

	/* Commit the partitions and build a partitions structure */
	partitions = pllPartitionsCommit(partitionInfo, alignmentData);

	/* We don't need the the intermedia partition queue structure anymore */
	pllQueuePartitionsDestroy(&partitionInfo);

	/* eliminate duplicate sites from the alignment and update weights vector */
	pllAlignmentRemoveDups(alignmentData, partitions);

	pllTreeInitTopologyForAlignment(tr, alignmentData);
	/* Connect the alignment and partition structure with the tree structure */
	if (!pllLoadAlignment(tr , alignmentData,
			partitions, PLL_DEEP_COPY)) {
		printf("Incompatible tree/alignment combination\n");
	}
	tr->randomNumberSeed = 12345;
    pllComputeRandomizedStepwiseAdditionParsimonyTree(tr, partitions);
    Tree2String(tr->tree_string, tr, partitions, tr->start->back, PLL_FALSE, PLL_TRUE, PLL_FALSE, PLL_FALSE, PLL_FALSE, PLL_SUMMARIZE_LH, PLL_FALSE, PLL_FALSE);
	printf("%s", tr->tree_string);

	/* Initialize the model. Note that this function will also perform a full
	 tree traversal and evaluate the likelihood of the tree. Therefore, you
	 have the guarantee that tr->likelihood the valid likelihood */
	pllInitModel(tr, partitions, alignmentData);

	double f[4] = { 0.249, 0.262, 0.251, 0.238 };

	double q[6] = { 1.565, 2.453, 1.806, 1.914, 2.914, 1.0 };

	pllLinkAlphaParameters("0", partitions);
	pllLinkFrequencies("0", partitions);
	pllLinkRates("0", partitions);

	pllSetFixedAlpha(0.902, 0, partitions, tr);
	pllSetFixedBaseFrequencies(f, 4, 0, partitions, tr);
	pllSetFixedSubstitutionMatrix(q, 6, 0, partitions, tr);

	pllEvaluateGeneric(tr, partitions, tr->start, PLL_TRUE, PLL_FALSE);
	pllTreeEvaluate(tr, partitions, 64);
	printf("Logl of the parsimony tree: %f\n", tr->likelihood);

	/* UNTIL NOW EVERYTHING IS CORRECT */

	/* Now try to read in a different tree */
	/* read in a different topology which has the same taxa set as the first tree (corresponding to the same alignment) */
	newick1 = pllNewickParseFile("example.11234.newick");
	pllTreeInitTopologyNewick(tr, newick1, PLL_FALSE);
	if (!pllLoadAlignment(tr, alignmentData, partitions, PLL_DEEP_COPY)) {
		fprintf(stderr, "Incompatible tree/alignment combination\n");
		return (EXIT_FAILURE);
	}
	pllInitModel(tr, partitions, alignmentData);

        f[0] = 0.249; f[1] = 0.262; f[2] = 0.251; f[3] = 0.238;
        q[0] = 1.565; q[1] = 2.453; q[2] = 1.806; q[3] = 1.914; q[4] = 2.914; q[5] = 1.0;

	pllLinkAlphaParameters("0", partitions);
	pllLinkFrequencies("0", partitions);
	pllLinkRates("0", partitions);

	pllSetFixedAlpha(0.902, 0, partitions, tr);
	pllSetFixedBaseFrequencies(f, 4, 0, partitions, tr);
	pllSetFixedSubstitutionMatrix(q, 6, 0, partitions, tr);

	//updateFracChange(tr, partitions);
	/* We need to re-run the tree initialization here to update the branch length with new fracchange */
	pllTreeInitTopologyNewick(tr, newick1, PLL_FALSE);
	pllEvaluateGeneric(tr, partitions, tr->start, PLL_TRUE, PLL_FALSE);
        printf ("Fracchage: %f\n", tr->fracchange);
	printf("Log-likelihood of tree 2 (should be -11234.* but it is -13157.57354): %f\n", tr->likelihood);


	/* Do some cleanup */
	pllAlignmentDataDestroy(alignmentData);
	pllNewickParseDestroy(&newick1);
	pllPartitionsDestroy(tr, &partitions);
	pllDestroyInstance(tr);

	return (EXIT_SUCCESS);
}
