#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "../../src/pll.h"

int main(int argc, char * argv[]) {
	pllAlignmentData * alignmentData;
	pllInstance * tr;
	pllNewickTree * newick1;
	partitionList * partitions;
	pllQueue * partitionInfo;
	int i;
	pllInstanceAttr attr;
	pllRearrangeList * rearrangeList;

#ifdef _FINE_GRAIN_MPI
	pllInitMPI (&argc, &argv);
#endif

	if (argc != 4) {
		fprintf(stderr,
				"usage: %s [phylip-file] [newick-file] [partition-file]\n",
				argv[0]);
		return (EXIT_FAILURE);
	}

	/* Set the PLL instance attributes */
	attr.rateHetModel = PLL_GAMMA;
	attr.fastScaling = PLL_FALSE;
	attr.saveMemory = PLL_FALSE;
	attr.useRecom = PLL_FALSE;
	attr.randomNumberSeed = 0xDEADBEEF;
	attr.numberOfThreads = 8; /* This only affects the pthreads version */

	/* Create a PLL tree */
	tr = pllCreateInstance(&attr);

	/* Parse a PHYLIP file */
	alignmentData = pllParseAlignmentFile(PLL_FORMAT_PHYLIP, argv[1]);

	if (!alignmentData) {
		fprintf(stderr, "Error while parsing %s\n", argv[1]);
		return (EXIT_FAILURE);
	}

	/* Parse a NEWICK file */
	newick1 = pllNewickParseFile(argv[2]);

	if (!newick1) {
		fprintf(stderr, "Error while parsing newick file %s\n", argv[2]);
		return (EXIT_FAILURE);
	}
	if (!pllValidateNewick(newick1)) /* check whether the valid newick tree is also a tree that can be processed with our nodeptr structure */
	{
		fprintf(stderr, "Invalid phylogenetic tree\n");
		printf("%d\n", errno);
		//return (EXIT_FAILURE);
	}

	/* Parse the partitions file into a partition queue structure */
	partitionInfo = pllPartitionParse(argv[3]);

	/* Validate the partitions */
	if (!pllPartitionsValidate(partitionInfo, alignmentData)) {
		fprintf(stderr, "Error: Partitions do not cover all sites\n");
		return (EXIT_FAILURE);
	}

	/* Commit the partitions and build a partitions structure */
	partitions = pllPartitionsCommit(partitionInfo, alignmentData);

	/* We don't need the the intermedia partition queue structure anymore */
	pllQueuePartitionsDestroy(&partitionInfo);

	/* eliminate duplicate sites from the alignment and update weights vector */
	pllAlignmentRemoveDups(alignmentData, partitions);

	/* Set the topology of the PLL tree from a parsed newick tree */
	pllTreeInitTopologyNewick(tr, newick1, PLL_FALSE);

	/* Or instead of the previous function use the next commented line to create
	 a random tree topology
	 pllTreeInitTopologyRandom (tr, alignmentData->sequenceCount, alignmentData->sequenceLabels); */

	/* Connect the alignment and partition structure with the tree structure */
	if (!pllLoadAlignment(tr, alignmentData, partitions, PLL_DEEP_COPY)) {
		fprintf(stderr, "Incompatible tree/alignment combination\n");
		return (EXIT_FAILURE);
	}

	/* Initialize the model. Note that this function will also perform a full
	 tree traversal and evaluate the likelihood of the tree. Therefore, you
	 have the guarantee that tr->likelihood the valid likelihood */
	pllInitModel(tr, partitions, alignmentData);

	double f[4] = { 0.249, 0.262, 0.251, 0.238 };

	double q[6] = { 1.565, 2.453, 1.806, 1.914, 2.914, 1.0 };

	pllLinkAlphaParameters("0", partitions);
	pllLinkFrequencies("0", partitions);
	pllLinkRates("0", partitions);

	pllSetFixedAlpha(0.902, 0, partitions, tr);
	pllSetFixedBaseFrequencies(f, 4, 0, partitions, tr);
	pllSetFixedSubstitutionMatrix(q, 6, 0, partitions, tr);

	//updateFracChange(tr, partitions);

	/* We need to re-run the tree initialization here to update the branch length with new fracchange */
	pllTreeInitTopologyNewick(tr, newick1, PLL_FALSE);

	/* Test to see whether the newick string is read in correctly */
	/*
	boolean printBranchLengths = PLL_TRUE;
	Tree2String(tr->tree_string, tr, partitions, tr->start->back,
			printBranchLengths, 1, 0, 0, 0, PLL_SUMMARIZE_LH, 0, 0);
			*/

	printf ("%s\n\n", tr->tree_string);

	/* pllTreeEvaluate (tr, partitions, 64); */
	pllEvaluateGeneric(tr, partitions, tr->start, PLL_TRUE, PLL_FALSE);

	printf("Log-likelihood of tree 1 (should be -11280.* and it was computed correctly): %f\n", tr->likelihood);

	/* read in a different topology which has the same taxa set as the first tree (corresponding to the same alignment) */
	pllNewickTree *newick2 = pllNewickParseFile("example.11234.newick");
	pllTreeInitTopologyNewick(tr, newick2, PLL_FALSE);
	pllEvaluateGeneric(tr, partitions, tr->start, PLL_TRUE, PLL_FALSE);
	pllInitModel(tr, partitions, alignmentData);

        f[0] = 0.249; f[1] = 0.262; f[2] = 0.251; f[3] = 0.238;
        q[0] = 1.565; q[1] = 2.453; q[2] = 1.806; q[3] = 1.914; q[4] = 2.914; q[5] = 1.0;

	pllLinkAlphaParameters("0", partitions);
	pllLinkFrequencies("0", partitions);
	pllLinkRates("0", partitions);

	pllSetFixedAlpha(0.902, 0, partitions, tr);
	pllSetFixedBaseFrequencies(f, 4, 0, partitions, tr);
	pllSetFixedSubstitutionMatrix(q, 6, 0, partitions, tr);

	//updateFracChange(tr, partitions);

	/* We need to re-run the tree initialization here to update the branch length with new fracchange */
	pllTreeInitTopologyNewick(tr, newick2, PLL_FALSE);
	pllEvaluateGeneric(tr, partitions, tr->start, PLL_TRUE, PLL_FALSE);
        printf ("Fracchage: %f\n", tr->fracchange);
	printf("Log-likelihood of tree 2 (should be -11234.* but it is -13157.57354): %f\n", tr->likelihood);


	/* Do some cleanup */
	pllAlignmentDataDestroy(alignmentData);
	pllNewickParseDestroy(&newick1);
	pllNewickParseDestroy(&newick2);
	pllPartitionsDestroy(tr, &partitions);
	pllDestroyInstance(tr);

	return (EXIT_SUCCESS);
}
